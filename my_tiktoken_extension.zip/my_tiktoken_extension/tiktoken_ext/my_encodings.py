from tiktoken.load import data_gym_to_mergeable_bpe_ranks, load_tiktoken_bpe

ENDOFTEXT = "<|endoftext|>"
FIM_PREFIX = "<|fim_prefix|>"
FIM_MIDDLE = "<|fim_middle|>"
FIM_SUFFIX = "<|fim_suffix|>"
FIN_INSTN_ID = "<FinInstnId>"
FIN_INSTN_ID_END = "</FinInstnId>"
BICFI = "<BICFI>"
BICFI_END = "</BICFI>"
NM = "<Nm>"
NM_END = "</Nm>"
COUNTRY = "<Ctry>"
COUNTRY_END = "</Ctry>"
ENDOFPROMPT = "<|endofprompt|>"


def cl100k_base_custom():
    mergeable_ranks = load_tiktoken_bpe(
        "https://openaipublic.blob.core.windows.net/encodings/cl100k_base.tiktoken",
        expected_hash="223921b76ee99bde995b7ff738513eef100fb51d18c93597a113bcffe865b2a7",
    )
    special_tokens = {
        
        FIM_PREFIX: 100258,
        FIM_MIDDLE: 100259,
        FIM_SUFFIX: 100260,
        FIN_INSTN_ID: 100261,
        FIN_INSTN_ID_END: 100262,
        BICFI: 100263,
        BICFI_END: 100264,
        NM: 100265,
        NM_END: 100266,
        COUNTRY: 100267,
        COUNTRY_END: 100268,
        ENDOFTEXT: 100269,
        ENDOFPROMPT: 100276,
    }
    return {
        "name": "cl100k_base_custom",
        "pat_str": r"""'(?i:[sdmt]|ll|ve|re)|[^\r\n\p{L}\p{N}]?+\p{L}+|\p{N}{1,3}| ?[^\s\p{L}\p{N}]++[\r\n]*|\s*[\r\n]|\s+(?!\S)|\s+""",
        "mergeable_ranks": mergeable_ranks,
        "special_tokens": special_tokens,
    }




ENCODING_CONSTRUCTORS = {
    "cl100k_base_custom": cl100k_base_custom,
}
